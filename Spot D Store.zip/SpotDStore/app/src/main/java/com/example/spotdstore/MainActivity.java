package com.example.spotdstore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Spinner spType;
    Button btFind;
    SupportMapFragment supportMapFragment;
    GoogleMap map;
    FusedLocationProviderClient fusedLocationProviderClient;
    double currentLat = 0, currentLong = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Assigning Variables
        spType = findViewById(R.id.sp_type);
        btFind = findViewById(R.id.bt_find);
        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.google_map);
        final String [] placeTypeList = {"clothes","atm","bank","hospital"};

        final String [] placeNameList = {"Clothes","ATM","Bank","Hospital"};

        spType.setAdapter(new ArrayAdapter<>(MainActivity.this
                ,android.R.layout.simple_spinner_dropdown_item,placeNameList));

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
        {
            getCurrentLocation();
        }
        else
        {
            //IF Permission is denied
            //Request Permission
            ActivityCompat.requestPermissions(MainActivity.this
                    , new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 44);
        }

        btFind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Get selected position of the spanner
                int i = spType.getSelectedItemPosition();
                //Initialize url
                String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json" +
                        "?location=" + currentLat + "," + currentLong +
                        "&radius=5`000" +
                        "&type=" + placeTypeList[i] +
                        "&sensor=true" +
                        "&key=" + getResources().getString(R.string.google_map_key);
                //Execute place task method to download json data
                new PlaceTask().execute(url);
            }
        });
    }

    private void getCurrentLocation()
    {
        //Initialize Task Location
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                //When task is successful
                if(location!= null)
                {
                    //When location is not null or location is found
                    //Get current Latitude
                    currentLat = location.getLatitude();
                    //Get current Longitude
                    currentLong = location.getLongitude();
                    //Sync with maps again
                    supportMapFragment.getMapAsync(new OnMapReadyCallback() {
                        @Override
                        public void onMapReady(GoogleMap googleMap) {
                            // When map is ready
                            map = googleMap;
                            //Zoom In on Current Location on the Map
                            map.animateCamera(CameraUpdateFactory.newLatLngZoom(
                             new LatLng(currentLat,currentLong),10
                            ));
                        }
                    });
                }

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 44)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                //When permission is granted
                //Get the current Location by calling the method
                getCurrentLocation();
            }
        }
    }

    private class PlaceTask extends AsyncTask<String,Integer,String> {
        @Override
        protected String doInBackground(String... strings) {
            String data = null;
            try {
                //Initialize data
                 data = downloadUrl(strings[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return data;
        }

        @Override
        protected void onPostExecute(String s) {
            // Execute parser task;
            Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
            new ParseTask().execute(s);
        }
    }

    private String downloadUrl(String string) throws IOException {
        //Initialize URL
        URL url = new URL(string);
        //Initialize connection
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        //Connect application with the connection variable
        connection.connect();
        //Initialize Input Stream of Data
        InputStream stream = connection.getInputStream();
        //Initialize Buffer Reader
        BufferedReader reader = new  BufferedReader(new InputStreamReader(stream));
        //Initialize String Builder Class
        StringBuilder builder = new StringBuilder();
        //Initialize String variable
        String line = "";
        //Use while loop to read data
        while ((line = reader.readLine()) != null)
        {
            //Append the line variable
            builder.append(line);
        }
        // Get the appended data
        String data = builder.toString();
        // Close reader
        reader.close();
        // Return the collected data
        return data;
    }

    private class ParseTask extends AsyncTask<String,Integer, List<HashMap<String,String>>> {

        @Override
        protected List<HashMap<String, String>> doInBackground(String... strings) {
            //Create Json Parser class to parse the downloaded json file
            JsonParser jsonParser = new JsonParser();
            //Initialize HashMap List
            List<HashMap<String,String>> mapList = null;
            JSONObject object = null;
            try {
                //Initialize Json Object
                object = new JSONObject(strings[0]);
                //Parse Json Object
                mapList = jsonParser.parseResult(object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            //Return map list
            return mapList;

        }

        @Override
        protected void onPostExecute(List<HashMap<String, String>> hashMaps) {
            //Clear the Map
            map.clear();
            // Use map for loop
            for (int i=0; i<hashMaps.size(); i++)
            {
                //Initialize Hash Map
                HashMap<String,String> hashMapList = hashMaps.get(i);
                //Get latitude
                double lat = Double.parseDouble(hashMapList.get("lat"));
                // Get Longitude
                double lng = Double.parseDouble(hashMapList.get("lng"));
                //Get Name
                String name = hashMapList.get("name");
                //Concat Latitude and Longitude
                LatLng latLng = new LatLng(lat,lng);
                // Initialize Marker Option
                MarkerOptions options = new MarkerOptions();
                // Set position
                options.position(latLng);
                // Set title
                options.title(name);
                // Add marker on the map
                map.addMarker(options);




            }
        }
    }
}