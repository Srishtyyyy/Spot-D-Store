package com.example.spotdstore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class JsonParser {
    private HashMap<String,String> parseJsonObject(JSONObject object)
    {
        //Initialize the HashMap
        HashMap<String,String> dataList = new HashMap<>();
        try {
            //Get name from object
            String name = object.getString("name");
            //Get latitude and longitude
            String latitude = object.getJSONObject("geometry").getJSONObject("location").getString("lat");

            String longitude = object.getJSONObject("geometry").getJSONObject("location").getString("lng");
            // Put all of the values in the HashMap
            dataList.put("name",name);
            dataList.put("lat",latitude);
            dataList.put("lng",longitude);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return dataList;
    }

    private List<HashMap<String,String>> parseJsonArray(JSONArray jsonArray)
    {
        //Initialize Hasp Map list
        List<HashMap<String,String>> dataList = new ArrayList<>();
        for(int i = 0; i<jsonArray.length(); i++)
        {

            try {
                // Initialize Hasp Map
                HashMap<String,String> data = parseJsonObject((JSONObject) jsonArray.get(i));
                // Add HashMap data in HashMap list
                dataList.add(data);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return dataList;
    }

    public List<HashMap<String,String>> parseResult(JSONObject object)
    {
        //Initialize Json Array
        JSONArray jsonArray = null;
        //Get Array result
        try {
            jsonArray = object.getJSONArray("result");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return parseJsonArray(jsonArray);
    }
}
